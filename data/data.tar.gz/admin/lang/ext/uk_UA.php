<?php
$lang['403description'] = 'Доступ до сторінки заборонений';
$lang['404description'] = 'Сторінка не знайдена';
?>