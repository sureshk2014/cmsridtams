<?php
$lang['CSS']='CSS st&iacute;lsni&eth;';
$lang['about']='Um';
$lang['action']='A&eth;ger&eth;';
$lang['actionstatus']='A&eth;ger&eth;/Sta&eth;a';
$lang['active']='Virkt';
$lang['add']='B&aelig;ta vi&eth;';
$lang['addbookmark']='B&aelig;ta vi&eth; fl&yacute;tilei&eth;';
$lang['addcontent']='B&aelig;ta vi&eth; efni';
$lang['addcss']='B&aelig;ta vi&eth; CSS st&iacute;lsni&eth;i';
$lang['addcssassociation']='B&aelig;ta vi&eth; st&iacute;lsni&eth;s tengingu';
$lang['addgroup']='B&uacute;a til n&yacute;ja gr&uacute;ppu ';
$lang['addhtmlblob']='B&aelig;ta vi&eth; Efnissv&aelig;&eth;i';
$lang['additionaleditors']='A&eth;rir efnisritarar';
$lang['addstylesheet']='B&aelig;ta vi&eth; st&iacute;lsni&eth;i';
$lang['addtemplate']='B&aelig;ta vi&eth; n&yacute;ju templeiti';
$lang['adduser']='B&uacute;a til n&yacute;jan notanda';
$lang['addusertag']='B&aelig;ta vi&eth; notendaskipun (User Tag)';
$lang['admin']='Kerfisstj&oacute;rn';
$lang['adminaccess']='A&eth;gangur a&eth; innskr&aacute;ningu kerfisstj&oacute;ra';
$lang['admincallout']='Fl&yacute;tilei&eth;ir kerfisstj&oacute;ra';
$lang['admindescription']='Kerfisstj&oacute;ra f&uacute;nksj&oacute;nir';
$lang['adminhome']='A&eth;als&iacute;&eth;a kerfisstj&oacute;ra';
$lang['adminindent']='S&yacute;na innihald';
$lang['adminlog']='Atbur&eth;askr&aacute; kerfisstj&oacute;ra';
$lang['adminlogcleared']='Atbur&eth;askr&aacute; kerfisstj&oacute;ra var hreinsu&eth;';
$lang['adminlogdescription']='S&yacute;nir atbur&eth;askr&aacute; kerfisstj&oacute;rnunar';
$lang['adminlogempty']='Atbur&eth;askr&aacute; kerfisstj&oacute;ra er t&oacute;m';
$lang['adminpaging']='Fj&ouml;ldi efnisatri&eth;a sem &aacute; a&eth; s&yacute;na &aacute; hverri s&iacute;&eth;u &iacute; S&iacute;&eth;ulista';
$lang['adminpaneltitle']='Stj&oacute;rnbor&eth; CMS Made Simple';
$lang['adminprefs']='Stillingar notanda';
$lang['adminprefsdescription']='H&eacute;r stillir &thorn;&uacute; kerfisstj&oacute;rnun eftir &thorn;&iacute;nu h&ouml;f&eth;i';
$lang['adminsystemtitle']='Stj&oacute;rnkerfi CMS';
$lang['admintheme']='Kerfisstj&oacute;rnar &thorn;ema';
$lang['advanced']='&THORN;r&oacute;a&eth;';
$lang['aliasalreadyused']='Fl&yacute;tiv&iacute;sir er &thorn;egar &iacute; notu&eth; &aacute; annari s&iacute;&eth;u. Breyttu Fl&yacute;tiv&iacute;sir &iacute; Valkosta flipanum &iacute; eitthva&eth; anna&eth;. ';
$lang['aliasmustbelettersandnumbers']='Fl&yacute;tiv&iacute;sir ver&eth;ur a&eth; vera stafur e&eth;a tala';
$lang['aliasnotaninteger']='Fl&yacute;tiv&iacute;sir getur ekki veri&eth; heiltala';
$lang['allpagesmodified']='&Ouml;llum s&iacute;&eth;um breytt!';
$lang['apply']='Virkja';
$lang['applydescription']='Vista og halda &aacute;fram breytingum';
$lang['assignmentchanged']='Stillingar h&oacute;pa hafa veri&eth; uppf&aelig;r&eth;ar';
$lang['assignments']='Skipa notendum &iacute; h&oacute;pa';
$lang['associationexists']='&THORN;essi tenging er &thorn;egar til';
$lang['attachstylesheet']='Vi&eth;hengja st&iacute;lsni&eth;';
$lang['attachstylesheets']='Hengja st&iacute;lsni&eth; vi&eth;';
$lang['attachtemplate']='Hengja vi&eth; &thorn;etta s&iacute;&eth;usni&eth;';
$lang['attachtotemplate']='Hengja st&iacute;lsni&eth; vi&eth; s&iacute;&eth;usni&eth;';
$lang['author']='H&ouml;fundur';
$lang['autoinstallupgrade']='Sj&aacute;lfvirk uppsetning e&eth;a uppf&aelig;rsla';
$lang['back']='Aftur &iacute; stj&oacute;rnbor&eth;';
$lang['backtoplugins']='Aftur &iacute; Plugins lista';
$lang['blobexists']='Nafn efnissv&aelig;&eth;is er uppteki&eth;';
$lang['blobmanagement']='St&yacute;ring Efnissv&aelig;&eth;a';
$lang['blobs']='Gl&oacute;bal efnisblokkir';
$lang['bookmarks']='Fl&yacute;tilei&eth;ir';
$lang['cachable']='M&aacute; setja &iacute; fl&yacute;timinni';
$lang['cachecleared']='Cache hreinsa&eth;';
$lang['cachenotwritable']='Ekki er h&aelig;gt a&eth; skrifa &iacute; fl&yacute;timinnism&ouml;ppu og &thorn;v&iacute; ekki h&aelig;gt a&eth; hreinsa fl&yacute;timinni. Trygg&eth;u full skrif/les/keyrslur&eacute;ttindi &aacute; tmp/cache m&ouml;ppunni (chmod 777)';
$lang['cancel']='H&aelig;tta vi&eth;';
$lang['canceldescription']='H&aelig;tta vi&eth; breytingar';
$lang['cantchmodfiles']='Gat ekki breytt r&eacute;ttindum &aacute; sumum skr&aacute;m';
$lang['cantremove']='Ekki h&aelig;gt a&eth; fjarl&aelig;gja';
$lang['cantremovefiles']='Gat ekki fjarl&aelig;gt skr&aacute;r (r&eacute;ttindi?)';
$lang['changehistory']='Breyta s&ouml;gu';
$lang['changepermissions']='Breyta r&eacute;ttindum';
$lang['changepermissionsconfirm']='FAR&ETH;U VARLEGA\n\n&THORN;essi a&eth;ger&eth; mun reyna a&eth; tryggja a&eth; allar skr&aacute;r sem eru hluti af &thorn;essari m&oacute;d&uacute;lu ver&eth;i skrifanlegar af vef&thorn;j&oacute;ninum.\nErtu viss um a&eth; &thorn;&uacute; viljir halda &aacute;fram?';
$lang['clear']='Hreinsa';
$lang['clearadminlog']='Hreinsa admin logg.';
$lang['clearcache']='Hreinsa Cache';
$lang['code']='K&oacute;&eth;i';
$lang['confirmcancel']='Ertu viss um a&eth; &thorn;&uacute; viljir h&aelig;tta vi&eth; breytingarnar? Smelltu &aacute; OK til a&eth; h&aelig;tta vi&eth; allar breytingar. Smelltu &aacute; Cancel til a&eth; halda &aacute;fram a&eth; breyta.';
$lang['confirmdefault']='Are you sure you want to set site\&#039;s default page?';
$lang['confirmdeletedir']='Ertu viss um a&eth; &thorn;&uacute; viljir ey&eth;a &thorn;essari m&ouml;ppu og &ouml;llu innihaldi hennar?';
$lang['content']='Efni';
$lang['contentadded']='Efninu hefur veri&eth; b&aelig;tt &iacute; gagnagrunninn';
$lang['contentdeleted']='Fjarl&aelig;gjing &aacute; efni t&oacute;kst.';
$lang['contentdescription']='H&eacute;r b&aelig;tum vi&eth; inn e&eth;a breytum efni.';
$lang['contentmanagement']='Efnis umsj&oacute;n';
$lang['contenttype']='Tegund efnis';
$lang['contentupdated']='Uppf&aelig;rsla &aacute; efni t&oacute;kst fullkomlega.';
$lang['contract']='Fela undirflokka';
$lang['contractall']='Fela alla flokka';
$lang['copy']='K&oacute;pera';
$lang['copystylesheet']='Afrita st&iacute;lsni&eth;';
$lang['copytemplate']='K&oacute;pera template';
$lang['core']='Kjarni';
$lang['create']='B&uacute;a til';
$lang['createnewfolder']='B&uacute;a til n&yacute;ja m&ouml;ppu';
$lang['cssalreadyused']='CSS nafn &thorn;egar &iacute; notkun';
$lang['cssmanagement']='CSS Umsj&oacute;n';
$lang['currentassociations']='N&uacute;verandi tenging';
$lang['currentdirectory']='N&uacute;verandi mappa';
$lang['currentgroups']='N&uacute;verandi gr&uacute;ppur';
$lang['currentpages']='N&uacute;verandi s&iacute;&eth;ur';
$lang['currenttemplates']='N&uacute;verandi template';
$lang['currentusers']='N&uacute;verandi notendur';
$lang['custom404']='S&eacute;rstillt villubo&eth; &aacute; 404 villum';
$lang['database']='Gagnagrunnur';
$lang['databaseprefix']='Gagnagrunnsforskeyti';
$lang['databasetype']='Tegund gagnagrunns';
$lang['date']='Dags.';
$lang['date_format_string']='&Uacute;tlit dagsetninga';
$lang['date_format_string_help']='<em>strftime</em> forma&eth;ur dagasni&eth;s strengur';
$lang['default']='Sj&aacute;lfgefi&eth;';
$lang['defaultpagecontent']='Sj&aacute;lfgefi&eth; innihald s&iacute;&eth;u';
$lang['defaultparentpage']='Sj&aacute;lgefin yfirs&iacute;&eth;a';
$lang['delete']='Ey&eth;a';
$lang['deleteassociationconfirm']='Ertu viss uma &eth; &thorn;&uacute; viljir ey&eth;a tengingum vi&eth; - %s - ?';
$lang['deleteconfirm']='Ertu viss um a&eth; &thorn;&uacute; viljir ey&eth;a';
$lang['deletecontent']='Ey&eth;a efni';
$lang['deletecss']='Ey&eth;a CSS';
$lang['deletepages']='Ey&eth;a &thorn;essum s&iacute;&eth;um?';
$lang['deletetemplate']='Ey&eth;a st&iacute;lsni&eth;um';
$lang['deletetemplates']='Ey&eth;a templeitum';
$lang['dependencies']='H&aacute;&eth; &ouml;&eth;ru';
$lang['depsformodule']='%s m&oacute;d&uacute;la er h&aacute;&eth; &thorn;essu';
$lang['description']='L&yacute;sing';
$lang['directoryabove']='mappa fyrir ofan n&uacute;verandi sta&eth;setningu';
$lang['directoryexists']='&THORN;essi mappa er &thorn;egar til';
$lang['disablesafemodewarning']='Aftengja &ouml;ryggisham kerfisstj&oacute;ra';
$lang['down']='Ni&eth;ur';
$lang['download']='Hla&eth;a ni&eth;ur';
$lang['edit']='Breyta';
$lang['editbookmark']='Breyta fl&yacute;tilei&eth;';
$lang['editconfiguration']='Breyta stillingum';
$lang['editcontent']='Breyta efni';
$lang['editcss']='Breyta CSS st&iacute;lsni&eth;i';
$lang['editcsssuccess']='CSS st&iacute;lsni&eth; uppf&aelig;rt';
$lang['editeventhandler']='S&yacute;sla me&eth; atbur&eth;i';
$lang['editgroup']='Breyta gr&uacute;ppu';
$lang['edithtmlblob']='Breyta Efnissv&aelig;&eth;i';
$lang['edithtmlblobsuccess']='Efnissv&aelig;&eth;i uppf&aelig;rt';
$lang['editpage']='Breyta s&iacute;&eth;u';
$lang['editstylesheet']='Breyta st&iacute;lsni&eth;i';
$lang['edittemplate']='Breyta s&iacute;&eth;usni&eth;i';
$lang['edittemplatesuccess']='S&iacute;&eth;usni&eth; uppf&aelig;rt';
$lang['edituser']='Breyta notanda';
$lang['editusertag']='Breyta notendaskipun.';
$lang['email']='Netfang';
$lang['enablecustom404']='Virkja &thorn;&iacute;n eigin 404 skilabo&eth; (S&iacute;&eth;a finnst ekki)';
$lang['enablesitedown']='Virkja skilabo&eth; um a&eth; vefsv&aelig;&eth;i&eth; s&eacute; ni&eth;ri';
$lang['encoding']='Stafasett';
$lang['error_delete_default_parent']='&THORN;&uacute; getur ekki eytt s&iacute;&eth;u sem er foreldri a&eth;als&iacute;&eth;unnar.';
$lang['errorattempteddowngrade']='Uppsetning &aacute; &thorn;essum m&oacute;d&uacute;l myndi koma &uacute;t sem ni&eth;urf&aelig;rsla. H&aelig;tt vi&eth; a&eth;ger&eth;';
$lang['errorcantcreatefile']='Gat ekki b&uacute;i&eth; til skr&aacute; (r&eacute;ttinda vandam&aacute;l?)';
$lang['errorchildcontent']='&THORN;etta efni &aacute; undirefni. Vinsamlegast fjarl&aelig;g&eth;u &thorn;a&eth; fyrst.';
$lang['errorcopyingstylesheet']='Villa vi&eth; afritun &aacute; st&iacute;lsni&eth;i';
$lang['errorcopyingtemplate']='Villa &iacute; afritun &aacute; templeiti';
$lang['errorcouldnotparsexml']='Villa vi&eth; lestur &aacute; XML skr&aacute;. Vertu viss um a&eth; &thorn;&uacute; s&eacute;rt a&eth; hla&eth;a inn .xml skr&aacute; en ekki .tar.gz e&eth;a .zip skr&aacute;. ';
$lang['errorcreatingassociation']='Villa vi&eth; a&eth; b&uacute;a til tengingu';
$lang['errorcssinuse']='&THORN;etta st&iacute;lsni&eth; er enn &iacute; notkun af s&iacute;&eth;usni&eth;um e&eth;a s&iacute;&eth;um. Vinsamlegast fjarl&aelig;g&eth;u &thorn;&aelig;r tengingar fyrst. ';
$lang['errordefaultpage']='Get ekki eytt sj&aacute;lfgefinni s&iacute;&eth;u. Veldu a&eth;ra s&iacute;&eth;u sem sj&aacute;lfgefna fyrst.';
$lang['errordeletingassociation']='Villa vi&eth; a&eth; ey&eth;a tengingu';
$lang['errordeletingcss']='Villa &thorn;egar ey&eth;a &aacute;tti css';
$lang['errordeletingdirectory']='Gat ekki eytt m&ouml;ppu. R&eacute;ttindavandam&aacute;l?';
$lang['errordeletingfile']='Gat ekki eytt skr&aacute;. R&eacute;ttindavandam&aacute;l?';
$lang['errordirectorynotwritable']='Engin r&eacute;ttindi til a&eth; skrifa &iacute; m&ouml;ppu';
$lang['errordtdmismatch']='DTD &uacute;tg&aacute;fu vantar e&eth;a er &oacute;samh&aelig;f&eth; &iacute; XML skr&aacute;';
$lang['errorgettingcssname']='Villa, n&aelig; ekki nafni St&iacute;lsni&eth;s';
$lang['errorgettingtemplatename']='Villa, n&aelig; ekki S&iacute;&eth;usni&eth;i';
$lang['errorincompletexml']='XML skr&aacute; er skemmd e&eth;a &oacute;gild';
$lang['errorinsertingblob']='Villa vi&eth; innsetningu Efnissv&aelig;&eth;is';
$lang['errorinsertingcss']='Villa vi&eth; innsetningu st&iacute;lsni&eth;s';
$lang['errorinsertinggroup']='Villa vi&eth; innsetningu h&oacute;ps';
$lang['errorinsertingtag']='Villa vi&eth; innsetningu notandaskipanar';
$lang['errorinsertingtemplate']='Villa vi&eth; innsetningu &aacute; s&iacute;&eth;usni&eth;i';
$lang['errorinsertinguser']='Villa vi&eth; innsetningu &aacute; notanda';
$lang['errorinstallfailed']='Uppsetning &aacute; &thorn;essari m&oacute;d&uacute;lu t&oacute;kst ekki';
$lang['errormodulenotfound']='Innri villa, finn ekki m&oacute;d&uacute;lu keyrandi';
$lang['errormodulenotloaded']='Innri villa, m&oacute;d&uacute;lan hefur ekki veri&eth; r&aelig;st';
$lang['errormoduleversionincompatible']='M&oacute;d&uacute;ll passar ekki fyrir &thorn;essa &uacute;tg. af kerfinu';
$lang['errormodulewontload']='Vandam&aacute;l vi&eth; a&eth; r&aelig;sa m&oacute;d&uacute;lu';
$lang['errornofilesexported']='Villa, get ekki flutt &uacute;t skr&aacute; sem XML';
$lang['errorretrievingcss']='Villa, gat ekki n&aacute;&eth; &iacute; st&iacute;lsni&eth;';
$lang['errorretrievingtemplate']='Villa gat ekki n&aacute;&eth; &iacute; s&iacute;&eth;usni&eth;';
$lang['errortemplateinuse']='&THORN;etta s&iacute;&eth;usni&eth; er nota&eth; af einhverri s&iacute;&eth;u. Vinsamlegast aftengdu &thorn;a&eth; fr&aacute; s&iacute;&eth;unni. ';
$lang['errorupdatingcss']='Villa vi&eth; uppf&aelig;rslu &aacute; st&iacute;lsni&eth;i';
$lang['errorupdatinggroup']='Villa vi&eth; uppf&aelig;rslu &aacute; gr&uacute;ppu';
$lang['errorupdatingpages']='Villa, ekki t&oacute;kst a&eth; uppf&aelig;ra s&iacute;&eth;u';
$lang['errorupdatingtemplate']='Villa, ekki t&oacute;kst a&eth; uppf&aelig;ra templeit';
$lang['errorupdatinguser']='Villa, ekki t&oacute;kst a&eth; uppf&aelig;ra notanda';
$lang['errorupdatingusertag']='Villa vi&eth; uppf&aelig;rslu notandaskipunar';
$lang['erroruserinuse']='&THORN;essi notandi er enn&thorn;&aacute; skr&aacute;&eth;ur eigandi s&iacute;&eth;na. Skr&aacute;&eth;u fyrst annan notanda sem eiganda &aacute;&eth;ur en &thorn;&uacute; ey&eth;ir &thorn;essum.';
$lang['event']='Atbur&eth;ur';
$lang['event_desc_addgrouppost']='Sent eftir a&eth; n&yacute;r h&oacute;pur er b&uacute;inn til';
$lang['event_desc_addgrouppre']='Sent &aacute;&eth;ur en n&yacute;r h&oacute;pur er b&uacute;inn til';
$lang['event_desc_addstylesheetpost']='Sent eftir a&eth; n&yacute;tt st&iacute;lsni&eth; er b&uacute;i&eth; til';
$lang['event_desc_addstylesheetpre']='Sent &aacute;&eth;ur en n&yacute;tt st&iacute;lsni&eth; er b&uacute;i&eth; til';
$lang['event_desc_addtemplatepost']='Sent eftir a&eth; n&yacute;tt templeit eru b&uacute;i&eth; til';
$lang['event_desc_addtemplatepre']='Sent &aacute;&eth;ur en n&yacute;tt templeit eru b&uacute;i&eth; til';
$lang['event_desc_adduserdefinedtagpost']='Sent eftir a&eth; notandaskipun er sett inn';
$lang['event_desc_adduserdefinedtagpre']='Sent &aacute;&eth;ur en notandaskipun er sett inn';
$lang['event_desc_adduserpost']='Sent eftir a&eth; n&yacute;r notandi er b&uacute;inn til';
$lang['event_desc_adduserpre']='Sent &aacute;&eth;ur en n&yacute;r notandi er b&uacute;inn til';
$lang['event_desc_changegroupassignpost']='Sent eftir a&eth; stillingar h&oacute;pa eru vista&eth;ir';
$lang['event_desc_changegroupassignpre']='Sent &aacute;&eth;ur en stillingar h&oacute;pa eru vista&eth;ir';
$lang['event_desc_contentstylesheet']='Sent before the sytlesheet is sent to the browser';
$lang['event_desc_deletegrouppost']='Sent eftir a&eth; gr&uacute;ppu er eytt &uacute;r kerfinu';
$lang['event_desc_deletegrouppre']='Sent &aacute;&eth;ur en gr&uacute;ppu er eytt &uacute;r kerfinu';
$lang['event_desc_deletestylesheetpost']='Sent eftir a&eth; st&iacute;lsni&eth;i er eytt &uacute;r kerfinu';
$lang['event_desc_deletestylesheetpre']='Sent &aacute;&eth;ur en st&iacute;lsni&eth;i er eytt &uacute;r kerfinu';
$lang['event_desc_deletetemplatepost']='Sent eftir a&eth; templeiti er eytt &uacute;r kerfinu';
$lang['event_desc_deletetemplatepre']='Sent &aacute;&eth;ur en templeiti er eytt &uacute;r kerfinu';
$lang['event_desc_deleteuserdefinedtagpost']='Sent eftir a&eth; notendaskipun er eytt &uacute;t';
$lang['event_desc_deleteuserdefinedtagpre']='Sent &aacute;&eth;ur en notendaskipun eytt &uacute;t';
$lang['event_desc_deleteuserpost']='Sent eftir a&eth; notanda er eytt &uacute;r kerfinu';
$lang['event_desc_deleteuserpre']='Sent &aacute;&eth;ur en notanda er eytt &uacute;r kerfinu';
$lang['event_desc_editgrouppost']='Sent eftir a&eth; breytingar &aacute; gr&uacute;ppu eru vista&eth;ar';
$lang['event_desc_editgrouppre']='Sent &aacute;&eth;ur en breytingar &aacute; gr&uacute;ppu eru vista&eth;ar';
$lang['event_desc_editstylesheetpost']='Sent eftir a&eth; breytingar &aacute; st&iacute;lsni&eth;i eru vista&eth;ar';
$lang['event_desc_editstylesheetpre']='Sent &aacute;&eth;ur en breytingar &aacute; st&iacute;lsni&eth;i eru vista&eth;ar';
$lang['event_desc_edittemplatepost']='Sent eftir a&eth; breytingar &aacute; templeiti eru vista&eth;ar';
$lang['event_desc_edittemplatepre']='Sent &aacute;&eth;ur en breytingar &aacute; templeiti eru vista&eth;ar';
$lang['event_desc_edituserdefinedtagpost']='Sent eftir a&eth; notendaskipun er uppf&aelig;r&eth;';
$lang['event_desc_edituserdefinedtagpre']='Sent &aacute;&eth;ur en notendaskipun er uppf&aelig;r&eth;';
$lang['event_desc_edituserpost']='Sent eftir a&eth; breytingar &aacute; notanda eru vista&eth;ar';
$lang['event_desc_edituserpre']='Sent &aacute;&eth;ur en breytingar &aacute; notanda eru vista&eth;ar';
$lang['event_desc_loginpost']='Sent eftir a&eth; notandi skr&aacute;ir sig inn &aacute; kerfisstj&oacute;rnar sv&aelig;&eth;i&eth;';
$lang['event_desc_logoutpost']='Sent eftir a&eth; notandi skr&aacute;ir sig &uacute;taf kerfisstj&oacute;rnarsv&aelig;&eth;inu';
$lang['event_desc_moduleinstalled']='Sent eftir a&eth; m&oacute;d&uacute;la er sett upp';
$lang['event_desc_moduleuninstalled']='Sent eftir a&eth; m&oacute;d&uacute;la er tekin &uacute;t';
$lang['event_desc_moduleupgraded']='Sent eftir uppf&aelig;rslu &aacute; m&oacute;d&uacute;lu';
$lang['event_desc_smartyprecompile']='Sent before any content destined for smarty is sent to for processing';
$lang['event_description']='L&yacute;sing a&eth;ger&eth;ar';
$lang['event_help_addglobalcontentpost']='<p>Sent after a new global content block is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_addglobalcontentpre']='<p>Sent before a new global content block is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_addgrouppost']='<p>Sent after a new group is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_addgrouppre']='<p>Sent before a new group is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_addstylesheetpost']='<p>Sent after a new stylesheet is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_addstylesheetpre']='<p>Sent before a new stylesheet is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_addtemplatepost']='<p>Sent after a new template is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_addtemplatepre']='<p>Sent before a new template is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_adduserpost']='<p>Sent after a new user is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_adduserpre']='<p>Sent before a new user is created.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_changegroupassignpost']='<p>Sent after group assignments are saved.</p>
<h4>Parameters></h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
<li>&#039;users&#039; - Array of references to user objects now belonging to the affected group.</li>
';
$lang['event_help_changegroupassignpre']='<p>Sent before group assignments are saved.</p>
<h4>Parameters></h4>
<ul>
<li>&#039;group&#039; - Reference to the group object.</li>
<li>&#039;users&#039; - Array of references to user objects belonging to the group.</li>
';
$lang['event_help_contentdeletepost']='<p>Sent after content is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected content object.</li>
</ul>
';
$lang['event_help_contentdeletepre']='<p>Sent before content is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected content object.</li>
</ul>
';
$lang['event_help_contenteditpost']='<p>Sent after edits to content are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected content object.</li>
</ul>
';
$lang['event_help_contenteditpre']='<p>Sent before edits to content are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected content object.</li>
</ul>
';
$lang['event_help_contentpostcompile']='<p>Sent after content has been processed by smarty.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected content text.</li>
</ul>
';
$lang['event_help_contentpostrender']='<p>Sent before the combined html is sent to the browser.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the html text.</li>
</ul>
';
$lang['event_help_contentprecompile']='<p>Sent before content is sent to smarty for processing.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected content text.</li>
</ul>
';
$lang['event_help_contentstylesheet']='<p>Sent before the sytlesheet is sent to the browser.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected stylesheet text.</li>
</ul>
';
$lang['event_help_deleteglobalcontentpost']='<p>Sent after a global content block is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_deleteglobalcontentpre']='<p>Sent before a global content block is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_deletegrouppost']='<p>Sent after a group is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_deletegrouppre']='<p>Sent before a group is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_deletestylesheetpost']='<p>Sent after a stylesheet is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_deletestylesheetpre']='<p>Sent before a stylesheet is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_deletetemplatepost']='<p>Sent after a template is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_deletetemplatepre']='<p>Sent before a template is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_deleteuserpost']='<p>Sent after a user is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_deleteuserpre']='<p>Sent before a user is deleted from the system.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_editglobalcontentpost']='<p>Sent after edits to a global content block are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_editglobalcontentpre']='<p>Sent before edits to a global content block are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block object.</li>
</ul>
';
$lang['event_help_editgrouppost']='<p>Sent after edits to a group are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_editgrouppre']='<p>Sent before edits to a group are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;group&#039; - Reference to the affected group object.</li>
</ul>
';
$lang['event_help_editstylesheetpost']='<p>Sent after edits to a stylesheet are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_editstylesheetpre']='<p>Sent before edits to a stylesheet are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;stylesheet&#039; - Reference to the affected stylesheet object.</li>
</ul>
';
$lang['event_help_edittemplatepost']='<p>Sent after edits to a template are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_edittemplatepre']='<p>Sent before edits to a template are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template object.</li>
</ul>
';
$lang['event_help_edituserpost']='<p>Sent after edits to a user are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_edituserpre']='<p>Sent before edits to a user are saved.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_globalcontentpostcompile']='<p>Sent after a global content block has been processed by smarty.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block text.</li>
</ul>
';
$lang['event_help_globalcontentprecompile']='<p>Sent before a global content block is sent to smarty for processing.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;global_content&#039; - Reference to the affected global content block text.</li>
</ul>
';
$lang['event_help_loginpost']='<p>Sent after a user logs into the admin panel.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_logoutpost']='<p>Sent after a user logs out of the admin panel.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;user&#039; - Reference to the affected user object.</li>
</ul>
';
$lang['event_help_smartypostcompile']='<p>Sent after any content destined for smarty has been processed.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected text.</li>
</ul>
';
$lang['event_help_smartyprecompile']='<p>Sent before any content destined for smarty is sent to for processing.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;content&#039; - Reference to the affected text.</li>
</ul>
';
$lang['event_help_templatepostcompile']='<p>Sent after a template has been processed by smarty.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template text.</li>
</ul>
';
$lang['event_help_templateprecompile']='<p>Sent before a template is sent to smarty for processing.</p>
<h4>Parameters</h4>
<ul>
<li>&#039;template&#039; - Reference to the affected template text.</li>
</ul>
';
$lang['event_name']='Nafn a&eth;ger&eth;ar';
$lang['eventhandlerdescription']='Tengja notendaskipanir vi&eth; atbur&eth;i';
$lang['eventhandlers']='Atbur&eth;ur';
$lang['execute']='Keyra';
$lang['expand']='S&yacute;na undirflokka';
$lang['expandall']='S&yacute;na alla flokka';
$lang['export']='Flytja &uacute;t';
$lang['extensions']='Aukahlutir';
$lang['extensionsdescription']='M&oacute;d&uacute;lur, t&ouml;g og &yacute;mislegt anna&eth; skemmtilegt.';
$lang['false']='&Oacute;satt';
$lang['filecreatedirnodoubledot']='M&ouml;ppunafn m&aacute; ekki innihalda &#039;..&#039;.';
$lang['filecreatedirnoname']='Get ekki b&uacute;i&eth; til nafnlausa m&ouml;ppu.';
$lang['filecreatedirnoslash']='M&ouml;ppunafn m&aacute; ekki innihalda &#039;/&#039; e&eth;a &#039;\&#039;.';
$lang['filemanagement']='S&yacute;sla me&eth; skr&aacute;r';
$lang['filemanager']='Skr&aacute;a umsj&oacute;n';
$lang['filemanagerdescription']='Upphla&eth;a og stj&oacute;rna skr&aacute;m';
$lang['filename']='Skr&aacute;anafn';
$lang['filenotuploaded']='Ekki var h&aelig;gt a&eth; upphla&eth;a skr&aacute;. R&eacute;ttindavandam&aacute;l?';
$lang['files']='Skr&aacute;r';
$lang['filesize']='Skr&aacute;arst&aelig;r&eth;';
$lang['filterbymodule']='S&iacute;a eftir m&oacute;d&uacute;lum';
$lang['firstname']='Fornafn';
$lang['forums']='Spjallbor&eth;';
$lang['frontendlang']='Sj&aacute;lfgefi&eth; tungum&aacute;l fyrir framhluta vefsins';
$lang['gcb_wysiwyg']='Virkja GCB WYSIWYG';
$lang['gcb_wysiwyg_help']='Virkja myndr&aelig;nan ritil vi&eth; skrif &iacute; Efnissv&aelig;&eth;i';
$lang['global_umask']='Skr&aacute;aheimildastilling (umask)';
$lang['globalconfig']='Algildar stillingar';
$lang['globalmetadata']='Algild l&yacute;sig&ouml;gn';
$lang['group']='H&oacute;pur';
$lang['groupassignmentdescription']='H&eacute;r getur&eth;u sett notendur &iacute; h&oacute;pa';
$lang['groupassignments']='Stillingar h&oacute;pa';
$lang['groupmanagement']='S&yacute;sla me&eth; h&oacute;p';
$lang['groupmembers']='Stillingar h&oacute;pa';
$lang['groupname']='Nafn h&oacute;ps';
$lang['grouppermissions']='Heimildir h&oacute;ps';
$lang['groupperms']='R&eacute;ttindi h&oacute;pa';
$lang['grouppermsdescription']='Stilling &aacute; r&eacute;ttindum og a&eth;gangsheimildum fyrir h&oacute;pa';
$lang['groups']='H&oacute;par';
$lang['groupsdescription']='H&eacute;r hefur &thorn;&uacute; umsj&oacute;n me&eth; h&oacute;pum';
$lang['hasdependents']='H&aacute;&eth; &ouml;&eth;ru';
$lang['help']='Hj&aacute;lp';
$lang['helpaddtemplate']='<p>S&iacute;&eth;usni&eth; er &thorn;a&eth; sem stj&oacute;rnar &uacute;tliti s&iacute;&eth;unna &thorn;innar.</p><p>Hanna&eth;u &uacute;tliti&eth; h&eacute;r og b&aelig;ttu einnig vi&eth; CSS st&iacute;lsni&eth;i &uacute;r St&iacute;lsni&eth;a flokknum svo &thorn;&uacute; getir st&yacute;rt &uacute;tliti &aacute; &yacute;msum hlutum vefsins.</p>';
$lang['helplisttemplate']='<p>&THORN;essi s&iacute;&eth;a gerir &thorn;&eacute;r kleyft a&eth; breyta, ey&eth;a og b&uacute;a til s&iacute;&eth;usni&eth;.</p><p>Til a&eth; b&uacute;a til n&yacute;tt s&iacute;&eth;usni&eth; smellir&eth;u &aacute; <u>B&aelig;ta vi&eth; s&iacute;&eth;usni&eth;i</u> takkann.</p><p>Ef &thorn;&uacute; vilt stilla allar s&iacute;&eth;ur &thorn;annig a&eth; &thorn;&aelig;r noti sama s&iacute;&eth;usni&eth; smellir&eth;u &aacute; <u>Nota fyrir allt efni</u> tengilinn.</p><p>Ef &thorn;&uacute; vilt afrita s&iacute;&eth;usni&eth; smelltu &aacute; <u>Afrita</u> &iacute;koni&eth; og &thorn;&uacute; munt ver&eth;a be&eth;inn um a&eth; sk&iacute;ra afriti&eth;.</p>';
$lang['helpwithsection']='%s Hj&aacute;lp';
$lang['hide_help_links']='Fela hj&aacute;lpar tengla';
$lang['hide_help_links_help']='Haka&eth;u vi&eth; &thorn;ennan kassa til a&eth; aftengja wiki og m&oacute;d&uacute;lu hj&aacute;lpartengla &iacute; fyrirs&ouml;gnum s&iacute;&eth;na.';
$lang['hostname']='Nafn &thorn;j&oacute;ns';
$lang['htmlblobdescription']='Algild efnissv&aelig;&eth;i eru efniskassar sem &thorn;&uacute; getur sett &aacute; s&iacute;&eth;ur e&eth;a s&iacute;&eth;usni&eth;. ';
$lang['htmlblobs']='Algild efnissv&aelig;&eth;i';
$lang['idnotvalid']='Uppgefi&eth; au&eth;kenni er &oacute;gilt';
$lang['illegalcharacters']='&Oacute;gildir stafir &iacute; %s reit.';
$lang['imagemanagement']='Mynda ums&yacute;sla';
$lang['imagemanager']='Mynda umsj&oacute;n';
$lang['imagemanagerdescription']='Upphla&eth;a/breyta e&eth;a ey&eth;a myndum';
$lang['images']='Myndaumsj&oacute;n';
$lang['inactive']='&Oacute;virkt';
$lang['indent']='Draga inn s&iacute;&eth;ulista til a&eth; &yacute;kja stigveldi';
$lang['info_edituser_password']='Breyttu &thorn;essum reit til a&eth; breyta lykilor&eth;i notandans';
$lang['info_edituser_passwordagain']='Breyttu &thorn;essum reit til a&eth; breyta lykilor&eth;i notandans';
$lang['informationmissing']='Uppl&yacute;singar vantar';
$lang['install']='Innsetning';
$lang['installdirwarning']='<em><strong>Var&uacute;&eth;:</strong></em> uppsetningar mappan (install) er enn til sta&eth;ar. Vinsamlegast eyddu henni.';
$lang['installed']='Uppsett';
$lang['invalidcode']='&Oacute;gildur k&oacute;&eth;i';
$lang['invalidcode_brace_missing']='&Oacute;jafn fj&ouml;ldi sviga';
$lang['invalidtemplate']='Templeiti&eth; er ekki valid';
$lang['itemid']='Au&eth;kennisn&uacute;mer atri&eth;is';
$lang['itemname']='Nafn atri&eth;is';
$lang['jsdisabled']='&THORN;&uacute; ver&eth;ur a&eth; hafa Javascript virkt til a&eth; geta nota&eth; &thorn;etta.';
$lang['langparam']='Breytan er notu&eth; til a&eth; stilla hva&eth;a tungum&aacute;l er nota&eth; &iacute; framenda kerfis. Ekki til sta&eth;ar n&eacute; &thorn;&ouml;rf fyrir &iacute; &ouml;llum m&oacute;d&uacute;lum. ';
$lang['language']='Tungum&aacute;l';
$lang['last_modified_at']='S&iacute;&eth;ast breytt';
$lang['last_modified_by']='S&iacute;&eth;ast breytt';
$lang['lastname']='F&ouml;&eth;urnafn';
$lang['layout']='&Uacute;tlit';
$lang['layoutdescription']='Stillingar fyrir &uacute;tlit s&iacute;&eth;u';
$lang['liststylesheets']='St&iacute;lsni&eth;';
$lang['loginprompt']='Settu inn virkar a&eth;gangsuppl&yacute;singar til a&eth; komast inn &iacute; kerfisstj&oacute;rn.';
$lang['logintitle']='CMS Made Simple Kerfisstj&oacute;rnar a&eth;gangur';
$lang['logout']='&Uacute;tskr&aacute;';
$lang['main']='A&eth;alval';
$lang['mainmenu']='A&eth;alval';
$lang['managebookmarks']='Umsj&oacute;n me&eth; fl&yacute;tilei&eth;um';
$lang['managebookmarksdescription']='H&eacute;r hefur&eth;u umsj&oacute;n me&eth; kerfisstj&oacute;ra fl&yacute;tilei&eth;um';
$lang['maximumversion']='H&aacute;marks &uacute;tg&aacute;fa';
$lang['maximumversionsupported']='Sty&eth;ur  h&aacute;marks &uacute;tg&aacute;fu af CMSMS';
$lang['mediatype']='Tegund mi&eth;lunar';
$lang['mediatype_']='Ekkert stillt: Mun hafa &aacute;hrif &iacute; &ouml;llum mi&eth;lum';
$lang['mediatype_all']='all : Virkar &iacute; &ouml;llum mi&eth;lum.';
$lang['mediatype_aural']='aural : &AElig;tla&eth; fyrir talgervla.';
$lang['mediatype_braille']='braille : &AElig;tla&eth; fyrir braille blindraleturs lesara sem n&yacute;ta s&eacute;r snertingu.';
$lang['mediatype_embossed']='embossed : &AElig;tla&eth; fyrir braille blindraleturs prentara.';
$lang['mediatype_handheld']='handheld : &AElig;tla&eth; fyrir handt&ouml;lvur.';
$lang['mediatype_print']='print : &AElig;tla&eth; fyrir prentun og fyrir skj&ouml;l sem eru sko&eth;u&eth; &aacute; skj&aacute; &iacute; forsko&eth;un prentunar.';
$lang['mediatype_projection']='projection : &AElig;tla&eth; fyrir skj&aacute;varpa og gl&aelig;ruprentun.';
$lang['mediatype_screen']='screen : &AElig;tla&eth; fyrir t&ouml;lvuskj&aacute;i. ';
$lang['mediatype_tty']='tty : &AElig;tla&eth; fyrir mi&eth;la sem sem nota fasta st&aelig;r&eth; af letri, frumst&aelig;&eth;a t&ouml;lvuskj&aacute;i. ';
$lang['mediatype_tv']='tv : &AElig;tla&eth; fyrir sj&oacute;nvarpsskj&aacute;i og svipa&eth;a mi&eth;la. ';
$lang['menutext']='Nafn menutakka';
$lang['metadata']='L&yacute;sig&ouml;gn';
$lang['minimumversion']='L&aacute;gmarks &uacute;tg&aacute;fa';
$lang['minimumversionrequired']='L&aacute;gmarks krafa um &uacute;tg&aacute;fu CMSMS';
$lang['missingdependency']='Vantar h&aelig;&eth;i';
$lang['missingparams']='Sumar breytur vantar e&eth;a eru &oacute;gilfar';
$lang['modifygroupassignments']='Breyta h&oacute;pa stillingum';
$lang['module']='M&oacute;d&uacute;ll';
$lang['module_help']='M&oacute;d&uacute;lu hj&aacute;lp';
$lang['module_name']='Nafn m&oacute;d&uacute;ls';
$lang['moduleabout']='Um %s m&oacute;d&uacute;linn';
$lang['moduledescription']='M&oacute;d&uacute;lur eru vi&eth;b&aelig;tur sem h&aelig;gt er a&eth; setja inn og bj&oacute;&eth;a &thorn;&aelig;r upp &aacute; &yacute;miskonar vi&eth;b&oacute;tar virkni. ';
$lang['moduleerrormessage']='Villur fyrir %s Module';
$lang['modulehelp']='Hj&aacute;lp fyrir %s m&oacute;d&uacute;linn';
$lang['moduleinstalled']='M&oacute;d&uacute;ll er &thorn;egar uppsettur';
$lang['moduleinstallmessage']='Uppsetningarskilabo&eth; fyrir %s m&oacute;d&uacute;lu';
$lang['moduleinterface']='%s Vi&eth;m&oacute;t';
$lang['modules']='M&oacute;d&uacute;lar';
$lang['modulesnotwritable']='Ekki er h&aelig;gt a&eth; skrifa &iacute; m&oacute;d&uacute;lum&ouml;ppu. Ef &thorn;&uacute; vilt geta sett inn m&oacute;d&uacute;lur me&eth; &thorn;v&iacute; a&eth; hla&eth;a inn XML skr&aacute; &thorn;&aacute; &thorn;arftu a&eth; tryggja full skrif/les/keyrslur&eacute;ttindi &aacute; m&oacute;d&uacute;lu m&ouml;ppunni (chmod 777)
The modules folder is not writable, if you would like to install modules by uploading an XML file you need to make the modules folder have full read/write/execute permissions (chmod 777).';
$lang['moduleuninstallmessage']='Skilabo&eth; fyrir ni&eth;urt&ouml;ku %s m&oacute;d&uacute;lu';
$lang['moduleupgradeerror']='Villa vi&eth; uppf&aelig;rslu m&oacute;d&uacute;ls.';
$lang['move']='Flytja';
$lang['movecontent']='F&aelig;ra s&iacute;&eth;ur';
$lang['myaccount']='&THORN;inn pr&oacute;f&iacute;ll';
$lang['myaccountdescription']='H&eacute;r getur&eth;u uppf&aelig;rt &thorn;&iacute;nar pers&oacute;nulegu stillingar';
$lang['myprefs']='M&iacute;nar stillingar';
$lang['myprefsdescription']='H&eacute;r getur &thorn;&uacute; stillt kerfisstj&oacute;rnunarsv&aelig;&eth;i&eth; til a&eth; vinna eins og &thorn;&uacute; vilt.';
$lang['name']='Nafn';
$lang['needpermissionto']='&THORN;&uacute; &thorn;arft leyfi &#039;%s&#039; til a&eth; framkv&aelig;ma &thorn;essa a&eth;ger&eth;';
$lang['needupgrade']='&THORN;arf uppf&aelig;rslu';
$lang['new_window']='n&yacute;r gluggi';
$lang['newstylesheetname']='Nafn n&yacute;s st&iacute;lsni&eth;s';
$lang['newtemplatename']='Nafn &aacute; n&yacute;ja templeiti&eth;';
$lang['next']='N&aelig;st';
$lang['no_orders_changed']='&THORN;&uacute; valdir a&eth; endurra&eth;a s&iacute;&eth;um, en breyttir ekki r&ouml;&eth;un &thorn;eirra. S&iacute;&eth;um hefur ekki veri&eth; endurra&eth;a&eth;.';
$lang['noaccessto']='Enginn a&eth;gangur a&eth; %s';
$lang['nocss']='Ekkert st&iacute;lsni&eth;';
$lang['nodefault']='Engar sj&aacute;lfgefnar stillingar valdar';
$lang['noentries']='Engar f&aelig;rslur';
$lang['nofieldgiven']='Engar %s uppgefnar!';
$lang['nofiles']='Engar skr&aacute;r';
$lang['nopaging']='S&yacute;na &ouml;ll atri&eth;i';
$lang['nopasswordmatch']='Lykilor&eth; stemma ekki';
$lang['norealdirectory']='Engin raunveruleg mappa gefin upp';
$lang['norealfile']='Engin raunveruleg skr&aacute; gefin upp';
$lang['notinstalled']='Ekki uppsett';
$lang['noxmlfileuploaded']='Skr&aacute; var ekki hla&eth;i&eth; inn. Til a&eth; setja inn m&oacute;d&uacute;lu me&eth; XML skr&aacute; &thorn;&aacute; &thorn;arftu a&eth; velja og hla&eth;a inn .xml skr&aacute; fr&aacute; t&ouml;lvunni &thorn;inni. ';
$lang['options']='Stillingar';
$lang['order']='R&ouml;&eth;';
$lang['order_too_large']='S&iacute;&eth;ur&ouml;&eth;un getur ekki veri&eth; st&aelig;rri en fj&ouml;ldi s&iacute;&eth;na &aacute; &thorn;v&iacute; &thorn;repi. S&iacute;&eth;ur&ouml;&eth;un ekki breytt. ';
$lang['order_too_small']='S&iacute;&eth;u getur ekki veri&eth; ra&eth;a&eth; me&eth; &quot;0&quot;. S&iacute;&eth;um var ekki endurra&eth;a&eth;';
$lang['originator']='Uppruni';
$lang['other']='Anna&eth;';
$lang['overwritemodule']='Yfirskrifa &thorn;&aacute; m&oacute;d&uacute;la sem fyrir eru';
$lang['owner']='Eigandi';
$lang['page_reordered']='Endurr&ouml;&eth;un s&iacute;&eth;unnar t&oacute;kst';
$lang['pagealias']='Samnefni s&iacute;&eth;u';
$lang['pages']='S&iacute;&eth;ur';
$lang['pages_reordered']='S&iacute;&eth;um hefur veri&eth; endurra&eth;a&eth;';
$lang['pagesdescription']='H&eacute;r breytum vi&eth; s&iacute;&eth;um og &ouml;&eth;ru efni vefsins';
$lang['parameters']='Breytur';
$lang['parent']='Foreldri';
$lang['password']='Lykilor&eth;';
$lang['passwordagain']='Lykilor&eth; (aftur)';
$lang['permission']='R&eacute;ttindi';
$lang['permissions']='R&eacute;ttindi';
$lang['permissionschanged']='R&eacute;ttindi hafa veri&eth; uppf&aelig;r&eth;';
$lang['pluginabout']='Um %s tag-i&eth;';
$lang['pluginhelp']='Hj&aacute;lp fyrir %s tag-i&eth;';
$lang['pluginmanagement']='Plugin umsj&oacute;n';
$lang['plugins']='Vi&eth;b&aelig;tur';
$lang['preferences']='Stillingar';
$lang['preferencesdescription']='H&eacute;r stillir &thorn;&uacute; hluti sem eiga vi&eth; um allt vefsv&aelig;&eth;i&eth;';
$lang['prefsupdated']='Stillingar hafa veri&eth; uppf&aelig;r&eth;ar';
$lang['preview']='Forsko&eth;a';
$lang['previewdescription']='Forsko&eth;a breytingar';
$lang['previous']='Fyrri';
$lang['read']='Lesa';
$lang['recentpages']='N&yacute;legar s&iacute;&eth;ur';
$lang['remove']='Fjarl&aelig;gja';
$lang['removeconfirm']='&THORN;essi a&eth;ger&eth; mun endanlega fjarl&aelig;gja &thorn;&aelig;r skr&aacute;r sem &thorn;essi m&oacute;d&uacute;ll er samsettur af. Ertu viss um a&eth; &thorn;&uacute; viljir halda &aacute;fram?';
$lang['removecssassociation']='Rj&uacute;fa samband vi&eth; st&iacute;lsni&eth;';
$lang['reorder']='Endurra&eth;a';
$lang['reorderpages']='Endurra&eth;a s&iacute;&eth;um';
$lang['results']='Ni&eth;urst&ouml;&eth;ur';
$lang['saveconfig']='Vista stillingar';
$lang['selectall']='Velja allt';
$lang['selecteditems']='Me&eth; &thorn;v&iacute; sem er vali&eth;';
$lang['selectgroup']='Velja h&oacute;p';
$lang['send']='Senda';
$lang['setallcontent']='Setja &aacute; allar s&iacute;&eth;ur';
$lang['setallcontentconfirm']='Ertu viss um a&eth; &thorn;&uacute; viljir stilla allar s&iacute;&eth;ur &aacute; &thorn;etta templeit?';
$lang['setfalse']='Stillt &aacute; &oacute;satt';
$lang['settrue']='Stilla &aacute; Satt';
$lang['showall']='S&yacute;na alla';
$lang['showbookmarks']='S&yacute;na fl&yacute;tilei&eth;ir kerfisstj&oacute;ra';
$lang['showinmenu']='S&yacute;na &iacute; tenglabor&eth;i';
$lang['showrecent']='S&yacute;na s&iacute;&eth;ur sem n&yacute;lega hefur veri&eth; unni&eth; me&eth;';
$lang['showsite']='S&yacute;na s&iacute;&eth;u';
$lang['sibling_duplicate_order']='Tv&aelig;r systkinas&iacute;&eth;ur geta ekki veri&eth; &aacute; sama sta&eth;. S&iacute;&eth;ur&ouml;&eth;un ekki breytt.';
$lang['siteadmin']='Vefstj&oacute;ri/Kerfisstj&oacute;ri';
$lang['sitedownmessage']='Skilabo&eth; um &oacute;virkt vefsv&aelig;&eth;i';
$lang['sitedownwarning']='<strong>Warning:</strong> Your site is currently showing a &quot;Site Down for Maintenence&quot; message.  Remove the %s file to resolve this.';
$lang['sitename']='Nafn vefs';
$lang['siteprefs']='Global Stillingar';
$lang['status']='Sta&eth;a';
$lang['stylesheet']='St&iacute;lsni&eth;';
$lang['stylesheetexists']='St&iacute;lsni&eth; er til';
$lang['stylesheets']='St&iacute;lsni&eth;';
$lang['stylesheetsdescription']='St&yacute;ring st&iacute;lsni&eth;a er &thorn;r&oacute;u&eth; lei&eth; til a&eth; vinna me&eth; CSS (Cascading Stylesheets), &oacute;h&aacute;&eth; s&iacute;&eth;usni&eth;um.';
$lang['stylesheetstodelete']='&THORN;essum st&iacute;lsni&eth;um ver&eth;ur eytt';
$lang['subitems']='Undirli&eth;ir';
$lang['submit']='Vista';
$lang['submitdescription']='Vista breytingar';
$lang['success']='T&oacute;kst';
$lang['syntaxhighlightertouse']='Velja tegund k&oacute;&eth;amerkingar';
$lang['tagdescription']='T&ouml;g eru einfaldar vi&eth;b&aelig;tur sem h&aelig;gt er a&eth; b&aelig;ta vi&eth; efnissv&aelig;&eth;i e&eth;a s&iacute;&eth;usni&eth;.';
$lang['tags']='Merki';
$lang['tagtousegcb']='Skipun sem notar &thorn;etta efnissv&aelig;&eth;i';
$lang['template']='S&iacute;&eth;usni&eth;';
$lang['templatecss']='Tengja s&iacute;&eth;usni&eth; vi&eth; st&iacute;lsni&eth;';
$lang['templateexists']='Nafn s&iacute;&eth;usni&eth;s &thorn;egar til sta&eth;ar';
$lang['templatemanagement']='Umsj&oacute;n me&eth; s&iacute;&eth;usni&eth;um';
$lang['templates']='S&iacute;&eth;usni&eth;';
$lang['templatesdescription']='H&eacute;r breytum vi&eth; s&iacute;&eth;usni&eth;um. S&iacute;&eth;usni&eth; st&yacute;ra &uacute;tliti og uppbyggingu vefsins. ';
$lang['templatestodelete']='&THORN;essum templeitum ver&eth;ur eytt';
$lang['test']='Pr&oacute;fa';
$lang['title']='Titill';
$lang['titleattribute']='L&yacute;sing (title attribute)';
$lang['tools']='T&oacute;l';
$lang['troubleshooting']='(Vi&eth;ger&eth;arstillingar)';
$lang['true']='Satt';
$lang['type']='Tegund';
$lang['typenotvalid']='Tegund &oacute;gild';
$lang['uninstall']='Fjarl&aelig;gja';
$lang['uninstallconfirm']='Ertu viss um a&eth; &thorn;&uacute; viljir fjarl&aelig;gja &thorn;ennan m&oacute;d&uacute;l?';
$lang['unknown']='&Oacute;&thorn;ekkt';
$lang['untested']='Ekki pr&oacute;fa&eth;';
$lang['up']='Upp';
$lang['updateperm']='Uppf&aelig;ra r&eacute;ttindi';
$lang['upgrade']='Uppf&aelig;ra';
$lang['upgradeconfirm']='Ertu viss um a&eth; &thorn;&uacute; viljir uppf&aelig;ra?';
$lang['uploadfile']='Hla&eth;a upp skr&aacute;';
$lang['uploadxmlfile']='Setja inn m&oacute;d&uacute;lu me&eth; XML skr&aacute;';
$lang['url']='URL - netsl&oacute;&eth;';
$lang['useadvancedcss']='Nota&eth;u &thorn;r&oacute;a&eth;a st&iacute;lsni&eth;astj&oacute;rnun';
$lang['user']='Notandi';
$lang['user_created']='S&eacute;rsm&iacute;&eth;a&eth;ar fl&yacute;tilei&eth;ir';
$lang['user_tag']='Notendaskipun (User Tag)';
$lang['userdefinedtags']='Notendaskipanir';
$lang['usermanagement']='Notenda ums&yacute;sla';
$lang['username']='Notandanafn';
$lang['usernameincorrect']='Notandanafn e&eth;a lykilor&eth; rangt';
$lang['userprefs']='Stillingar notanda';
$lang['users']='Notendur';
$lang['usersassignedtogroup']='Notandi tengdur vi&eth; h&oacute;p %s';
$lang['usersdescription']='H&eacute;r hefur &thorn;&uacute; umsj&oacute;n me&eth; notendum';
$lang['usersgroups']='Notendur og gr&uacute;ppur';
$lang['usersgroupsdescription']='Efni tengt notendum og gr&uacute;ppum';
$lang['usertagadded']='Notendaskipun b&aelig;tt vi&eth;.';
$lang['usertagdeleted']='Notendaskiptun eytt.';
$lang['usertagdescription']='T&ouml;g sem &thorn;&uacute; getur b&uacute;i&eth; til a&eth; breytt til a&eth; framkv&aelig;ma einst&ouml;k verkefni, beint &uacute;r vafranum. ';
$lang['usertagexists']='Skipun me&eth; &thorn;essu nafni er &thorn;egar til. Vinsamlegast nota&eth;u anna&eth; nafn. ';
$lang['usertags']='Notendaskipanir';
$lang['usertagupdated']='Notendaskipun uppf&aelig;r&eth;.';
$lang['usewysiwyg']='Nota WYSIWYG ritil fyrir efni';
$lang['version']='&Uacute;tg&aacute;fa';
$lang['view']='Sko&eth;a';
$lang['viewsite']='Sko&eth;a s&iacute;&eth;u';
$lang['warning_safe_mode']='<strong><em>WARNING:</em></strong> PHP Safe mode is enabled.  This will cause difficulty with files uploaded via the web browser interface, including images, theme and module XML packages.  You are advised to contact your site administrator to see about disabling safe mode.';
$lang['welcomemsg']='Velkomin %s';
$lang['wikihelp']='Hj&aacute;lparsamf&eacute;lagi&eth;';
$lang['wontdeletetemplateinuse']='&THORN;essi templeit eru &iacute; notkun og ver&eth;ur &thorn;essvegna ekki eytt';
$lang['write']='Skrifa';
$lang['wysiwygtouse']='Veldu WYSIWYG ritil til a&eth; nota';
?>