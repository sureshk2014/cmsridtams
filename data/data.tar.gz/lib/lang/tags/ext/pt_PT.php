<?php
$lang['function'] = 'As Fun&ccedil;&otilde;es podem desempenhar uma tarefa, ou consultar a base de dados, e tipicamente apresentar um resultado. Uso: {tag_nome_de_fun&ccedil;&atilde;o [atribut0=valor...]}';
$lang['modifier'] = 'Modificadores usam o resultado de uma fun&ccedil;&atilde;o Smarty e modificam-no. Uso: {$variavel|modificador[:arg:...]}';
$lang['postfilter'] = 'P&oacute;s-Filtros s&atilde;o chamados autom&aacute;ticamente pelo Smarty ap&oacute;s a compila&ccedil;&atilde;o de cada template. N&atilde;o podem ser usados manualmente.';
$lang['prefilter'] = 'Pr&eacute;-Filtros s&atilde;o chamados autom&aacute;ticamente pelo Smarty antes da compila&ccedil;&atilde;o de cada template. N&atilde;o podem ser usados manualmente.';
$lang['tag_about'] = 'Mostrar a informa&ccedil;&atilde;o de hist&oacute;rico e de autor para este plugin, se dispon&iacute;vel';
$lang['tag_adminplugin'] = 'Indica que a tag est&aacute; dispon&iacute;vel apenas na interface de administra&ccedil;&atilde;o, e &eacute; usada habitualmente nos templates dos m&oacute;dulos';
$lang['tag_cachable'] = 'Indica se o resultado do plugin pode ser guardado em cache (quando est&aacute; habilitada a cache Smarty). Plugins de Admin e modificadores n&atilde;o s&atilde;o eleg&iacute;veis.';
$lang['tag_help'] = 'Mostrar a ajuda (se existir) desta tag';
$lang['tag_name'] = 'Este &eacute; o nome da tag';
$lang['tag_type'] = 'O tipo de tag (fun&ccedil;&atilde;o, modificador, pr&eacute; ou p&oacute;s filtro)';
$lang['title_admin'] = 'Este plugin est&aacute; apenas dispon&iacute;vel apartir da consola de administra&ccedil;&atilde;o do CMSMS';
$lang['title_notadmin'] = 'Este plugin est&aacute; dispon&iacute;vel tanto na consola de administra&ccedil;&atilde;o como no frontend do site';
$lang['title_cachable'] = 'Este plugin pode ser guardado em cache';
$lang['title_notcachable'] = 'Este plugin n&atilde;o pode ser guardado em cache';
$lang['viewabout'] = 'Mostrar a informa&ccedil;&atilde;o de hist&oacute;rico e de autor para este m&oacute;dulo';
$lang['viewhelp'] = 'Mostrar a ajuda deste m&oacute;dulo';
$lang['utma'] = '156861353.958634181.1386869829.1386869829.1386869829.1';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1386869829.1.1.utmccn=(referral)|utmcsr=forum.cmsmadesimple.org|utmcct=/search.php|utmcmd=referral';
$lang['utmb'] = '156861353';
?>