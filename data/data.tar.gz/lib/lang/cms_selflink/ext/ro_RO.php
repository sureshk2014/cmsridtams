<?php
$lang['prev_label'] = 'Pagina precedentă:';
$lang['next_label'] = 'Pagina următoare:';
$lang['utma'] = '156861353.1023816423.1296940428.1298058074.1298887031.3';
$lang['utmz'] = '156861353.1298058074.2.2.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms';
$lang['qca'] = 'P0-1623500024-1296940428329';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>