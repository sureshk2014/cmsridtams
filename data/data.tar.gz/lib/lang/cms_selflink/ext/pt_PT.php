<?php
$lang['prev_label'] = 'P&aacute;gina anterior:';
$lang['next_label'] = 'P&aacute;gina seguinte:';
$lang['utma'] = '156861353.494797643.1328218505.1328218505.1328218505.1';
$lang['utmz'] = '156861353.1328218505.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-179206010-1319637219788';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>