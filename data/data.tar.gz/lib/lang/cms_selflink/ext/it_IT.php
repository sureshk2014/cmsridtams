<?php
$lang['prev_label'] = 'Pagina precedente:';
$lang['next_label'] = 'Pagina seguente:';
$lang['utma'] = '156861353.563238401015149400.1226334751.1288697345.1288700024.80';
$lang['qca'] = 'P0-2007686920-1251190815027';
$lang['utmz'] = '156861353.1288181013.71.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>