<?php
$lang['prev_label'] = 'Forrige side:';
$lang['next_label'] = 'N&aelig;ste side:';
$lang['qca'] = '1229601790-85243197-43260713';
$lang['utma'] = '156861353.389684394.1301142140.1301142140.1301254697.2';
$lang['utmz'] = '156861353.1301142140.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>