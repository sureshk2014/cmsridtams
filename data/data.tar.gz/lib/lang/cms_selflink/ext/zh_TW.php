<?php
$lang['prev_label'] = '上一頁：';
$lang['next_label'] = '下一頁：';
$lang['utma'] = '156861353.1962116278.1344436807.1344436807.1344456821.2';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1344436807.1.1.utmcsr=forum.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/ucp.php';
$lang['utmb'] = '156861353.1.10.1344456821';
?>