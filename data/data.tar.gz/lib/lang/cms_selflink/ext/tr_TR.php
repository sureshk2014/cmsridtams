<?php
$lang['prev_label'] = '&Ouml;nceki sayfa:';
$lang['next_label'] = 'Sonraki sayfa:';
$lang['utma'] = '156861353.1249837180.1276218286.1297348508.1297351199.9';
$lang['utmz'] = '156861353.1297348590.8.3.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-1332436756-1295403130439';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>