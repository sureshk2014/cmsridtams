<?php
$lang['prev_label'] = 'P&aacute;xina anterior:';
$lang['next_label'] = 'P&aacute;xina seguinte:';
$lang['utma'] = '156861353.914265427.1286356027.1304436550.1305015438.4';
$lang['qca'] = 'P0-284419044-1286356027016';
$lang['utmz'] = '156861353.1305015438.4.3.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms';
$lang['utmb'] = '156861353.1.10.1305015438';
$lang['utmc'] = '156861353';
?>