<?php
$lang['prev_label'] = 'Poprzednia strona:';
$lang['next_label'] = 'Następna strona:';
$lang['utma'] = '156861353.130117701.1281030249.1287928719.1288192868.15';
$lang['utmz'] = '156861353.1288192868.15.11.utmccn=(referral)|utmcsr=cmsms.org|utmcct=/|utmcmd=referral';
$lang['qca'] = 'P0-1706049120-1281030249820';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>