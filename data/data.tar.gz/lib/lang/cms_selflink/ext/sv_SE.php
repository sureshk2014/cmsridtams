<?php
$lang['prev_label'] = 'F&ouml;reg&aring;ende sida:';
$lang['next_label'] = 'N&auml;sta sida:';
$lang['utma'] = '156861353.397033920.1281357884.1286814578.1286820501.35';
$lang['utmz'] = '156861353.1281357884.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-1852641632-1281357886006';
$lang['utmb'] = '156861353.1.10.1286820501';
$lang['utmc'] = '156861353';
?>