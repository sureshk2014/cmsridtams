<?php
$lang['prev_label'] = 'Halaman sebelumnya:';
$lang['next_label'] = 'Halaman berikutnya:';
?>