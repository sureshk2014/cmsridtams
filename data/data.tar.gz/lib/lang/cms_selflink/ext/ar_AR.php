<?php
$lang['prev_label'] = 'الصفحة السابقة';
$lang['next_label'] = 'الصفحة التالية';
$lang['utma'] = '156861353.1884040792.1310371975.1310371975.1310371975.1';
$lang['utmz'] = '156861353.1310371975.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-1393246855-1304498842364';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>