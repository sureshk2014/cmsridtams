<?php
$lang['prev_label'] = 'Ankstesnis puslapis:';
$lang['next_label'] = 'Kitas puslapis:';
$lang['utma'] = '156861353.1299423357.1356775560.1356775560.1356798791.2';
$lang['utmz'] = '156861353.1356775560.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>