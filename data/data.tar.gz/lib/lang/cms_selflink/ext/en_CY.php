<?php
$lang['prev_label'] = 'Tudalen Flaenorol:';
$lang['next_label'] = 'Tudalen nesaf:';
$lang['utma'] = '156861353.34608955.1340622751.1340622751.1340622751.1';
$lang['utmz'] = '156861353.1340622751.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>