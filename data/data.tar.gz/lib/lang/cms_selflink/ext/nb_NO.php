<?php
$lang['prev_label'] = 'Forrige side:';
$lang['next_label'] = 'Neste side:';
$lang['utmz'] = '156861353.1283287349.3202.74.utmcsr=forum.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php';
$lang['utma'] = '156861353.179052623084110100.1210423577.1284225406.1284228895.3247';
$lang['qca'] = '1210971690-27308073-81952832';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.1.10.1284228895';
?>