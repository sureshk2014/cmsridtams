<?php
$lang['automatedtask_failed'] = 'Automatick&aacute; &uacute;loha selhala';
$lang['automatedtask_success'] = 'Automatick&aacute; &uacute;loha uspěla';
$lang['clearcache_taskname'] = 'Vymazat soubory ke&scaron;e';
$lang['clearcache_taskdescription'] = 'Automaticky vymaže soubory z adres&aacute;ře ke&scaron;e star&scaron;&iacute; jak nastaven&yacute; počet dn&iacute;';
$lang['testme'] = 'woot got it';
$lang['utma'] = '156861353.682233951.1296068669.1297424355.1297458685.21';
$lang['utmz'] = '156861353.1296946283.16.4.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-796774439-1296068668929';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>