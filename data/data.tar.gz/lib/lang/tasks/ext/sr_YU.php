<?php
$lang['adminlog_taskdescription'] = 'Ovaj zadatak će obrisati unose u administratorskom dnevniku koji su stariji od definisanog broja dana. Ovaj broj može biti pode&scaron;en u Globalnim pode&scaron;avanjima sajta.';
$lang['adminlog_taskname'] = 'Obri&scaron;i zastarele unose iz dnevnika';
$lang['automatedtask_failed'] = 'Automatizovani zadatak nije uspeo';
$lang['automatedtask_success'] = 'Automatizovani zadatak je bio uspe&scaron;an';
$lang['clearcache_taskname'] = 'Isprazni ke&scaron; datoteke';
$lang['clearcache_taskdescription'] = 'Automatski isprazni datoteke iz direktorijuma ke&scaron;a koje su starije od određenog broja dana';
$lang['testme'] = 'Juhu, uspelo je!';
$lang['utma'] = '156861353.1832385409.1326144498.1326144498.1326144498.1';
$lang['utmz'] = '156861353.1326144498.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353.2.10.1326144498';
$lang['utmc'] = '156861353';
?>