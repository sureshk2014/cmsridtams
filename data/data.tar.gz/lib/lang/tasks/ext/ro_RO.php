<?php
$lang['adminlog_taskdescription'] = 'Acest task va sterge intrarile din jurnal mai vechi decat o varsta specificata. Aceasta varsta poate fi setata in preferintele sitului.';
$lang['adminlog_taskname'] = 'Stergere intrari vechi din jurnal';
$lang['automatedtask_failed'] = 'Sarcina automata a esuat';
$lang['automatedtask_success'] = 'Sarcina automata rulata cu succes';
$lang['clearcache_taskname'] = 'Stergere Fisiere Cache';
$lang['clearcache_taskdescription'] = 'Stergere automata a fisierelor din folderul cache care sunt mai vechi decat numarul de zile setat';
$lang['testme'] = 'yup a luat-o';
$lang['utma'] = '156861353.1980774593.1327246436.1327246464.1327249131.3';
$lang['utmz'] = '156861353.1327246464.2.2.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>