<?php
$lang['adminlog_taskdescription'] = 'Denne opgave sletter poster i loggen, som er &aelig;ldre end en angiven alder. Denne alder kan indstilles i Side Administration - Global konfiguration - fanen Avanceret ops&aelig;tning.';
$lang['adminlog_taskname'] = 'Slet gamle log-poster';
$lang['automatedtask_failed'] = 'Automatiseret opgave fejlede';
$lang['automatedtask_success'] = 'Automatiseret opgave gennemf&oslash;rt';
$lang['clearcache_taskname'] = 'T&oslash;m cache-filer';
$lang['clearcache_taskdescription'] = 'Fjern automatisk filer i cache-mappen, som er &aelig;ldre end det p&aring; forh&aring;nd fastsatte antal dage';
$lang['testme'] = 'woot fik det';
$lang['utma'] = '156861353.1669182101.1357277528.1357300362.1357303144.6';
$lang['utmz'] = '156861353.1357277528.1.1.utmccn=(referral)|utmcsr=forum.cmsmadesimple.org|utmcct=/ucp.php|utmcmd=referral';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>