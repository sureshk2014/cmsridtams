<?php
$lang['adminlog_taskdescription'] = 'To opravilo bo izbrisalo log starej&scaron;i od določene starosti. To starost je mogoče nastaviti v nastavitvah.';
$lang['adminlog_taskname'] = 'Brisanje starih log vnosov';
$lang['automatedtask_failed'] = 'Samodejna naloga ni uspela';
$lang['automatedtask_success'] = 'Samodejna naloga je uspela';
$lang['clearcache_taskname'] = 'Izprazni datoteke predpomnilnika';
$lang['clearcache_taskdescription'] = 'Samodejno izprazni datoteke iz direktorija predpomnilnika, ki so starej&scaron;i od vnaprej nastavljenem &scaron;tevilu dni';
$lang['testme'] = 'Ja uspelo je';
$lang['qca'] = 'P0-1458450664-1284573084918';
$lang['utmz'] = '156861353.1338818723.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utma'] = '156861353.1673260288.1338818723.1338818723.1338822728.2';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>