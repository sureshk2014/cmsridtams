<?php
$lang['adminlog_taskdescription'] = 'This task will delete log entries older than a specified age. This age can be set in the site preferences.';
$lang['adminlog_taskname'] = 'حذف إدخالات السجل القديم';
$lang['automatedtask_failed'] = 'المهمة الفاشلة الآلي';
$lang['automatedtask_success'] = 'آلية العمل النجاح';
$lang['clearcache_taskname'] = 'مسح ملفات الكاش';
$lang['clearcache_taskdescription'] = 'الملفات تلقائيا واضحة من دليل التخزين المؤقت والتي تكون أقدم من عدد محدد مسبقا من أيام';
$lang['testme'] = 'حصلت عليها';
$lang['utma'] = '156861353.1091097006.1334784264.1335277717.1335612942.7';
$lang['utmz'] = '156861353.1334784264.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-1393246855-1304498842364';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>