<?php
$lang['adminlog_taskdescription'] = 'Táto úloha odstráni položky záznamu, ktoré sú staršie ako uvedené obdobie. Obdobie je možné nastaviť v nastaveniach stránky.';
$lang['adminlog_taskname'] = 'Vymazať staré položky v zázname';
$lang['automatedtask_failed'] = 'Automatizovaná úloha zlyhala';
$lang['automatedtask_success'] = 'Automatizovaná úloha bola úspešne dokončená';
$lang['clearcache_taskname'] = 'Vyčistiť súbory vyrovnávacej pamäte';
$lang['clearcache_taskdescription'] = 'Automatické vyčistenie súborov z priečinka vyrovnvácej pamäte, ktoré sú staršie ako tento počet dní';
$lang['testme'] = 'hotovo';
?>