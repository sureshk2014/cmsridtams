<?php
$lang['adminlog_taskdescription'] = 'Cette tâche supprime les entrées du journal des logs de plus d\'un certain âge. Cet âge peut être défini dans les préférences du site';
$lang['adminlog_taskname'] = 'Suppression des anciennes entrées des logs';
$lang['automatedtask_failed'] = 'Échec de l\'exécution des tâches automatiques';
$lang['automatedtask_success'] = 'Tâche automatique exécutée';
$lang['clearcache_taskname'] = 'Effacement des fichiers mis en cache';
$lang['clearcache_taskdescription'] = 'Effacer automatiquement les fichiers mis en cache qui sont plus anciens que le nombre de jour défini.';
$lang['testme'] = 'Yep';
?>