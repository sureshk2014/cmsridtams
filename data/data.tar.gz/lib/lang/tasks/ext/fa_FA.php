<?php
$lang['automatedtask_failed'] = 'وضعیت خودکار موفقیت آمیز نیست';
$lang['automatedtask_success'] = 'وضعیت خودکار با موفقیت انجام شد';
$lang['clearcache_taskname'] = 'حذف فایل&zwnj;های ذخیره&zwnj;سازی شده';
$lang['clearcache_taskdescription'] = 'فایل&zwnj;های پوشه ذخیره&zwnj;ساز بصورت خودکار حذف شوند. فایل&zwnj;های قدیمی و مربوط به روزهای گذشته';
$lang['testme'] = 'در آن اضافه شد';
$lang['utma'] = '156861353.710420388.1316517713.1316904406.1316905022.8';
$lang['utmz'] = '156861353.1316893031.4.2.utmccn=(referral)|utmcsr=dev.cmsmadesimple.org|utmcct=/projects/cmsms-persian|utmcmd=referral';
$lang['qca'] = 'P0-757906974-1307033581752';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>