<?php
$lang['adminlog_taskdescription'] = 'L&ouml;scht alle Eintr&auml;ge des Systemprotokolls, die &auml;lter als die Vorgabe sind. Das maximale Alter der Eintr&auml;ge kann in den Seiten-Einstellungen festgelegt werden.';
$lang['adminlog_taskname'] = 'Alte Eintr&auml;ge des Systemprotokolls l&ouml;schen';
$lang['automatedtask_failed'] = 'Automatisierte Aufgabe fehlgeschlagen';
$lang['automatedtask_success'] = 'Automatisierte Aufgabe erledigt';
$lang['clearcache_taskname'] = 'Zwischengespeicherte Dateien l&ouml;schen';
$lang['clearcache_taskdescription'] = 'L&ouml;scht alle Dateien aus den Verzeichnissen /tmp/cache und tmp/templates_c, die &auml;lter als die voreingestellte Anzahl an Tagen sind ';
$lang['testme'] = 'Erledigt';
$lang['utma'] = '156861353.793017015.1325501658.1325501658.1325501658.1';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1325501658.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
?>