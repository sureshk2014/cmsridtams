<?php
$lang['adminlog_taskdescription'] = 'See &uuml;lesanne kusutab logi kirjed, mis on m&auml;&auml;ratud vanusest vanemad. Seda vanust saab m&auml;&auml;rata kodulehe eelistustest.';
$lang['adminlog_taskname'] = 'Kustuta vanad logi kirjed';
$lang['automatedtask_failed'] = 'Automaatne &uuml;lesanne eba&otilde;nnestus';
$lang['automatedtask_success'] = 'Automaatne &uuml;lesanne &otilde;nnestus';
$lang['clearcache_taskname'] = 'Puhasta vahem&auml;lu failid';
$lang['clearcache_taskdescription'] = 'Automaatselt puhasta failid vahem&auml;lu kaustast, mis on eelnevalt seatud p&auml;evade arvust vanemad.';
$lang['testme'] = 'Juhhuu, sain k&auml;tte!';
$lang['utmz'] = '156861353.1334871120.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utma'] = '156861353.1784111165.1334871120.1335380760.1335463694.5';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>