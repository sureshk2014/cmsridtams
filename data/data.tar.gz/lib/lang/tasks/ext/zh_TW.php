<?php
$lang['adminlog_taskdescription'] = '此任務將刪除超過指定的日誌條目，這個期間，可以網站偏好設定中設定。';
$lang['adminlog_taskname'] = '刪除舊的日誌條目';
$lang['automatedtask_failed'] = '自動任務失敗';
$lang['automatedtask_success'] = '自動任務成功';
$lang['clearcache_taskname'] = '清除快取檔案';
$lang['clearcache_taskdescription'] = '自動清除超過預設天數快取目錄中檔案';
$lang['testme'] = '哇！我明白了';
$lang['utmz'] = '156861353.1344777498.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utma'] = '156861353.1155249065.1344777498.1344777498.1344783089.2';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>