<?php
$lang['adminlog_taskdescription'] = 'Pa&scaron;alinti senesnius nei nurodyta žurnalo įra&scaron;us. Amžius nurodomas svetainės nuostatose.';
$lang['adminlog_taskname'] = 'Pa&scaron;alinti senus žurnalo įra&scaron;us';
$lang['automatedtask_failed'] = 'Automatinės užduoties įvykdyti nepavyko';
$lang['automatedtask_success'] = 'Automatinė užduotis įvykdyta';
$lang['clearcache_taskname'] = 'I&scaron;valyti podėlį';
$lang['clearcache_taskdescription'] = 'Automati&scaron;kai pa&scaron;alinti podėlio aplanke esančius failus, senesnius negu nurodytas dienų skaičius';
$lang['testme'] = 'woot got it';
$lang['utma'] = '156861353.1299423357.1356775560.1356775560.1356798791.2';
$lang['utmz'] = '156861353.1356775560.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>