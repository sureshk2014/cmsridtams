<?php
$lang['adminlog_taskdescription'] = 'This task will delete log entries older than a specified age. This age can be set in the site preferences.';
$lang['adminlog_taskname'] = 'Delete old log entries';
$lang['automatedtask_failed'] = 'Mae&#039;r Tasg Awtomatig wedi Methu';
$lang['automatedtask_success'] = 'Mae&#039;r Tasg Awtomatig wedi llwyddo';
$lang['clearcache_taskname'] = 'Clirio Ffeiliau Cache';
$lang['clearcache_taskdescription'] = 'Clirio ffeiliau yn Awtomatig o&#039;r cyfeiriadur cache os ydyn nhw&#039;n hŷn na nifer o ddyddiau rhagosodedig';
$lang['testme'] = 'woot Wedi&#039;i dderbyn';
$lang['utma'] = '156861353.34608955.1340622751.1340622751.1340622751.1';
$lang['utmz'] = '156861353.1340622751.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>