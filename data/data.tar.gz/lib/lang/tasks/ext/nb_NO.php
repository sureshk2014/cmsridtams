<?php
$lang['adminlog_taskdescription'] = 'Denne oppgaven vil slette logg innlegg som er eldre enn en satt alder. Denne alder kan settes i nettstedspreferansene.';
$lang['adminlog_taskname'] = 'Slett gamle logginnlegg';
$lang['automatedtask_failed'] = 'Automatisk oppgavekj&oslash;ring mislyktes';
$lang['automatedtask_success'] = 'Automatisk oppgavekj&oslash;ring vellykket';
$lang['clearcache_taskname'] = 'Fjern mellomlagrede filer';
$lang['clearcache_taskdescription'] = 'Sletter automatisk filer fra mellomlagringskatalogen som er eldre enn et forh&aring;ndsbestemt antall dager';
$lang['testme'] = 'Jippy - fikk det til!';
?>