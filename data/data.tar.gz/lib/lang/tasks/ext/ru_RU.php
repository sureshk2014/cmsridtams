<?php
$lang['adminlog_taskdescription'] = 'Данная задача удаляет записи журнала старше определённой даты (задаваемой в настройках сайта).';
$lang['adminlog_taskname'] = 'Удалить старые записи журнала';
$lang['automatedtask_failed'] = 'Автоматическая задача завершилась неудачно';
$lang['automatedtask_success'] = 'Автоматическая задача завершилась успешно';
$lang['clearcache_taskname'] = 'Очистить файлы кеша';
$lang['clearcache_taskdescription'] = 'Автоматически удалять файлы кеша, если они старше предустановленного количества дней';
$lang['testme'] = 'хе-хе :)';
$lang['qca'] = 'P0-1681225218-1317202089531';
$lang['utma'] = '156861353.1030947472.1327739797.1328076005.1328079009.15';
$lang['utmz'] = '156861353.1327750796.2.2.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>